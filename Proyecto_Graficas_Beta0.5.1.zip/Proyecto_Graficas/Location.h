#pragma once

typedef struct Location
{
	double posX;
	double posY;
}Location;