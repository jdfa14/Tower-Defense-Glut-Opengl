#include "Wave.h"


Wave::Wave()
{
}


Wave::~Wave()
{
}
