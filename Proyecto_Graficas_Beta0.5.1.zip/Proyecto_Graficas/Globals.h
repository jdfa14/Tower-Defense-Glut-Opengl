#pragma comment(lib,"glew32")

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#include <list>
#include <fstream>
#include <string>
#include "glew.h" //las comillas sirven para que ese fichero se carge buscandolo en la propia carpeta del proyecto
#include "glut.h"