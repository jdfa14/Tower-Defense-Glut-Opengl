#include "Globals.h"
#include "BadAgent.h"

class Wave
{
private:
	std::vector<BadAgent> enemies;
public:
	Wave();
	~Wave();
};
