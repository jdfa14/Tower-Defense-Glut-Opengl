#pragma once
#include "StaticObject.h"
class Tower : public StaticObject
{
public:

	Tower()
	{
	}

	~Tower()
	{
	}
};

