#pragma once
#include "Mobile.h"
class Bullet : public Mobile
{
public:

	Bullet()
	{
	}

	~Bullet()
	{
	}
};

