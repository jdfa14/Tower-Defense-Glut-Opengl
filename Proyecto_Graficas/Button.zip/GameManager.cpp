#include "GameManager.h"


GameManager::GameManager()
{
}


GameManager::~GameManager()
{
}
