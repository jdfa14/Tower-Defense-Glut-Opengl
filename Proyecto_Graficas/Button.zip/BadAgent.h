#pragma once
#include "Mobile.h"
class BadAgent :
	public Mobile
{
public:

	BadAgent()
	{
	}

	~BadAgent()
	{
	}
private:
	string name;
};

