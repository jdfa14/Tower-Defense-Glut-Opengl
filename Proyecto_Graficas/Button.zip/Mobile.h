#pragma once
#include "PlaceableObject.h"
class Mobile :
	public PlaceableObject
{
public:

	Mobile()
	{
	}

	~Mobile()
	{
	}
};

